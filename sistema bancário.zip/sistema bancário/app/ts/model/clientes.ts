class Clientes {
    _clientes: Array<Cliente>;

    constructor() {
        this._clientes = new Array<Cliente>();
    }

    inserirCliente(cliente: Cliente): void {
        this._clientes.push(cliente);
    }

    removerCliente(cpf: string): void {
        if (this.pesquisarCpf(cpf)) {
            //this._clientes.splice()
        }

    }

    listarClientes(): Array<Cliente> {
        return this._clientes;
    }

    pesquisarCpf(cpf: string): Cliente {
        return this._clientes.find(cliente => cliente._cpf == cpf);
    }
}